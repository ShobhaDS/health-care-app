# HealthCare
<b>Healthcare</b> is an application that makes the communication between doctors and patients much easier.
<pre>
<img src="Images/1.png" height = "500px" width= "250px">    <img src="Images/2.png" height = "500px" width= "250px">    <img src="Images/3.png" height = "500px" width= "250px"> <br/></br>
<img src="Images/4.png" height = "500px" width= "250px">    <img src="Images/5.png" height = "500px" width= "250px">    <img src="Images/6.png" height = "500px" width= "250px"> <br/></br>
<img src="Images/7.png" height = "500px" width= "250px">    <img src="Images/8.png" height = "500px" width= "250px">    <img src="Images/9.png" height = "500px" width= "250px"> <br/></br>
<img src="Images/10.png" height = "500px" width= "250px">
</pre>
